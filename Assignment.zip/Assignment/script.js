const disclosures = document.querySelectorAll(".disclosure");

disclosures.forEach((disclosure) => {
  const question = disclosure.querySelector(".disclosure-question");
  const answer = disclosure.querySelector(".disclosure-answer");

  question.addEventListener("click", () => {
    answer.classList.toggle("active");

    const icon = question.querySelector(".chevron-icon");
    if (answer.classList.contains("active")) {
      icon.style.transform = "rotate(180deg)";
    } else {
      icon.style.transform = "rotate(0deg)";
    }
  });
});

// JSON-LD for structure data of 'Product'
const schema = `
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "Bright AI Banking App",
  "image": "https://www.brightcapital.com/images/bright-app.png",
  "description": "Bright AI Banking App helps you manage debt, improve credit scores, and achieve financial well-being.",
  "brand": {
    "@type": "Brand",
    "name": "Bright Capital"
  },
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "0.00",
    "availability": "https://schema.org/InStock",
    "url": "https://www.brightcapital.com/"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.8",
    "reviewCount": "1500"
  }
}
`;
document.head.insertAdjacentHTML('beforeend', `<script type="application/ld+json">${schema}</script>`);

